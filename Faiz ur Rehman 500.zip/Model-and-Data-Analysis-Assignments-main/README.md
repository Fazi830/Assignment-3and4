BSCS 4th Semester <br>
Course Title: Artificial Intelligence <br>
Assignment no. 3: Model Evaluation <br> 
Assignment no. 4: Data Analysis and Visualization
